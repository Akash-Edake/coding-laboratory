// var test1 ="cts";
// let test1 ="cts";
// const test1 ="cts";
// test1 ="cts Pune";

// String methods:
// typeof
// charAt
// upperCase
// lowercase
// substr
// slice(start index, end index -1)
// split ===> covert string into Array.
// concat: add mutliple string at single point
// length
// replace ==> replace otherwise print string as it is.
// indexOf ==> 
//search ===> 
// charCodeAt
//lastIndexOf
//valueOf
// var test3 = 'CTS Pune';
// test3.split('').reverse().join('');


// Arrays:
// push==> add end of array
// pop===> remove last element and return last removed element.
// unshift ==> add ele at start of arr and return length of new array.
// shift ==> remove first ele of array and retunr removed ele.
// slice(start index, end index-1)
// splice(start index, how many ele to remove, new elements to be added)
// join ==> arra to string.
// toString==> array to string
// concat
// map ==> perform operation on each ele of array.
// filter ===> perorfm operation on each ele and return those elements which satisfies the condition.
// reduce 
