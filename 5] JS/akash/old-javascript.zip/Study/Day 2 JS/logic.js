var test1 = true;
var test2 = false;


console.log(test1 && test2);

console.log(test1 || test2);

console.log(!test2);
