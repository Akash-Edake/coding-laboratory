var test1 = 2;
var test2 = 3;

// it will perform operation bit by bit.

// 0010
// 0011

console.log(test1 & test2);

console.log(test1 | test2);