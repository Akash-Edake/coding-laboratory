
var first = "CTS";
var second = "Pune";

var third = 15;
var fourth = 10;

// var result = first == second;
var result = third != fourth;
// console.log(result);

var test1 = 10;
var test2 = '10';
res = test1 == test2;
res1 = test1 === test2;
console.log(res); // true
console.log(res1); // false

