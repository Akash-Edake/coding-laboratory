var first = 10;

var second = 3;

var add = first + second;
var sub = first - second;
var mul = first * second;
var div = first / second;
var mod = first % second;
// console.log(add, sub, mul);
// console.log(mod); // modulus will always give remainnder
// pre increment
var inc = ++first;
var dec = --second;
//post increment
var inc1 = first++;
var dec1 = second--;

console.log(inc1, dec1);


