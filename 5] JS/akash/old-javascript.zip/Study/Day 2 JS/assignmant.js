var test1 = 10;
var test2 = 20;

// console.log(test1);
// test1 = test2;

test1 += test2; // test1 = test1 + test2;
console.log(test1);