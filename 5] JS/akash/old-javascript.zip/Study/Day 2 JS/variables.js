first = 5;
second = "CTS";
var third = [1,2,3];
let four = true;
var five = null;
const six = { name: 'CTS', age: 25 };
var seven = undefined;
// console.log(seven);
var ABC = 52;

var add = 5+5;
// console.log(add);

var _12Abc = 15;
abc_123 = 15;
//  var abc;
// console.log(abc);
var ABC = "CTS";
// console.log(abc);  // 52
// console.log(ABC);  // 55

var Pune ="Angular";
var text = 10 + 10 + Pune + "CTS" + 10 +15 + [1,2,3] + six.name;
var text2 = 10 + '10' +10;
console.log(text); //10 + CTS 