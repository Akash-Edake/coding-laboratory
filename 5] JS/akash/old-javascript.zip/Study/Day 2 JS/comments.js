console.log('this is to understand commnets');

// console.log('There are two types of commnets');
// above one is single line comment

/*console.log('Single Line comment');

console.log('Multi Line comments');

*/
// this one is multi line comment