var test1 = "CTS Pune";
// var test1 = 55;
var test2 = 35;
// console.log(typeof(test1));
// console.log(typeof(test2));



// expression 
// a= 5+5;

// (condition) ? option1 : option2

// (5+5) ? 11: 10;

var test3 = 55;
var test4 = 50;

var result = (test3==test4) ? 'Both are equal' : 'Both are not equal';

console.log(result);

