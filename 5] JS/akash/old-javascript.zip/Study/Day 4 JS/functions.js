
// function defincation

// function functionName(prameter-list){
//     // block of code goes here
// }

function add(a, b){
    var c = a + b;
    // console.log(c);
}
// add(22, 12);
var result = add(10, 12);
// console.log(result);
// until and unless u call any function, block of code inside function will not be executed.

function fullName(fName, LName){
    fullNm = fName + LName;
    return 'CTS Pune';
}

var result2= fullName('Rahul', 'Kulkarni');
console.log(result2);