
var test1; // declariation of variable 

// console.log(test1);
// console.log(typeof(test1));

// console.log(typeof(test5));
// console.log(test5); // we hsave not even declared test5
// var NULL = 12;
// var test5 = NULL;
// console.log(test5);
var test2 = null;
var test3 = null % 5;
// console.log(test3);
// console.log(test2);
// console.log(typeof(test2)); //object

var test5 = null +'CTS';
console.log(test5);



