var test1 = true;

console.log(test1);
console.log(typeof(test1))//boolean
console.log(!test1);
console.log(test1.valueOf());
console.log(test1.toString());