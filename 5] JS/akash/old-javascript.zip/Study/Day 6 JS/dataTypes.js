var test1 ="CTS Pune";
var test2 = true;

