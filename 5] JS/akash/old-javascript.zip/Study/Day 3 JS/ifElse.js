
var test1 = 12;

// if(test1== 10){
//     console.log('Values are correct ');
// }
// else{
//   console.log('Values are not correct');  
// }

if(test1== 10){
    console.log('Values are correct ');
}
else if(test1 == 11){
    console.log('Value is 11');
}
else if(test1 == 12){
    console.log('Value is 12');
}
else{
    console.log('Value are not matching');
}