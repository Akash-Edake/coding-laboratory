var test1 = 12;

if(test1 == 10){
    console.log('Values are correct');
}

