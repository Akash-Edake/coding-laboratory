
var count = 1;

while(count < 10){
    // console.log('Counting ' +count);
    count ++;
    // count = count +1;
}

var counter = 16;

do{
    console.log('This will be executed by default for first time');
    counter ++;
}
while(counter < 15)